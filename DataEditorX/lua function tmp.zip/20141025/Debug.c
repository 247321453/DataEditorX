========== Debug ==========
●void Debug.Message(any msg)
显示消息
●void Debug.AddCard(int code,int owner,int playerid,
int location,int sequence,int position [,bool proc = false])
添加卡片
	code 密码
	owner,playerid 所有者，当前玩家，下方 0,上方1
	location 加载区域，LOCATION_
	sequence 区域位置, 怪兽：0-4,魔法：4-0，5-场地,6-P右,7-P左
	position 显示方式 POSITION_
	proc 是否解除苏生限制
●void Debug.SetPlayerInfo(int playerid,int lp,
int startcount,int drawcount)
设置玩家信息
	playerid 下方 0,上方 1
	startcount 【未知】
	drawcount 【未知】
●void Debug.PreEquip(Card equip_card, Card target)
预装备
	equip_card 装备魔法卡
	target 被装备怪兽
●void Debug.PreSetTarget(Card t_card, Card target)
预选目标
	t_card 需要目标的卡片
	target 目标卡片
●void Debug.PreAddCounter(Card pcard,int ctype,int ccount)
添加指示物
	pcard 需要添加指示物的卡片
	ctype 指示物代码 （参考strings.conf）
	ccount 指示物数量
●void Debug.ReloadFieldBegin(interger flag)
重载场地布局开始
	flag 残局：DUEL_ATTACK_FIRST_TURN+DUEL_SIMPLE_AI
●void Debug.ReloadFieldEnd()
重载场地布局结束
●void Debug.SetAIName(string name)
设置AI的名字
●void Debug.ShowHint(string msg)
显示消息提示框