========== group ==========
●Group Group.CreateGroup()
新建一个空的卡片组
●Group Group.KeepAlive(Group g)
让卡片组持续
●Group Group.Clone(Group g)
新建卡片组g的副本
●Group Group.FromCards(Card c [, ...])
不定参数，把传入的所有卡组合成一个卡片组并返回
●void Group.DeleteGroup(Group g)
删除卡片组g
●void Group.Clear(Group g)
清空卡片组
●void Group.AddCard(Group g, Card c)
往g中增加c
●void Group.RemoveCard(Group g, Card c)
把c从g中移除
●Card Group.GetFirst(Group g)
返回g中第一张卡，并重置当前指针到g中第一张卡。
如果g中不存在卡则返回nil
●Card Group.GetNext(Group g)
返回并使指针指向下一张卡。如果g中不存在卡则返回nil
●int Group.GetCount(Group g)
返回g中卡的数量
●void Group.ForEach(Group g, function f)
以g中的每一张卡作为参数调用一次f
●Group Group.Filter(Group g, function f, Card ex [, ...])
过滤函数。从g中筛选满足筛选条件f并且不等于ex的卡。
从第4个参数开始为额外参数。
●int Group.FilterCount(Group g, function f, Card ex [, ...])
过滤函数。和上一个函数基本相同。不同指出在于此函数只返回满足条件的卡的数量。
●Group Group.FilterSelect(
Group g, int player, function f,int min, int max, Card ex, ...)
过滤函数。让玩家player从g中选择min-max张满足筛选条件f并且不等于ex的卡。
从第7个参数开始为额外参数。
●Group Group.Select(Group g, int player, int min, int max, Card ex)
让玩家player从g中选择min-max张不等于ex的卡。
●Group Group.RandomSelect(Group g, int player, int count)
让玩家player从g中随机选择count张卡。
因为是随机算则，所以参数player基本无用，由系统随机选取。
●bool Group.IsExists(Group g, function f, int count, Card ex, ...)
过滤函数。检查g中是否存在至少count张满足筛选条件f并且不等于ex的卡。
从第5个参数开始为额外参数。
●bool Group.CheckWithSumEqual(Group g, function f, int sum, int min)
子集求和判定函数。
	f为返回一个interger值的函数（通常用于同调判定）。
	检查g中是否存在一个数量至少为min的子集满足以f对子集的每一个元素求值的和等于sum。
	比如：g:CheckWithSumEqual(Card.GetSynchroLevel,7,2)
	检查g中是否存在一个子集满足子集的同调用等级之和等于7
●Group Group.SelectWithSumEqual(Group g, int player, function f, int sum, int min)
让玩家player从g中选取一个数量至少是min的子集使子集的特定函数的和等于sum
●bool Group.CheckWithSumGreater(Group g, function f, int sum)
子集求和判定函数之二。
f为返回一个interger值的函数（通常用于仪式判定）。
检查g中是否存在一个子集满足以f对子集的每一个元素求值的和刚好大于或者等于sum。
比如：g:CheckWithSumGreater(Card.GetRitualLevel,8)
	检查g中是否存在一个子集满足子集的仪式用等级之和大于等于8
	注：判定必须是“刚好”大于或者等于。
	以等级为例，要使等级合计大于等于8，可以选择LV1+LV7而不可以选择LV1+LV4+LV4
●Group Group.SelectWithSumGreater(Group g, int player, function f, int sum)
让玩家player从g中选取一个子集使子集的特定函数的和大于等于sum
●Group Group.GetMinGroup(Group g, function f)
f为返回一个interger值的函数。从g中筛选出具有最小的f的值的卡。用于地裂等卡。
●Group Group.GetMaxGroup(Group g, function f)
f为返回一个interger值的函数。从g中筛选出具有最大的f的值的卡。用于地碎等卡。
●int Group.GetSum(Group g, function f)
计算g中所有卡的取值的总和。f为为每张卡的取值函数。
●int Group.GetClassCount(Group g, function f)
计算g中所有卡的种类数量。f为分类的依据，返回相同的值视为同一种类。
●int Group.GetSortCount(Group g, function f)
【旧】计算g中所有卡的种类数量。
【新】GetClassCount(Group g, function f)
f为分类的依据，返回相同的值视为同一种类。
●Group Group.Remove(Group g, function f, ...)
过滤函数。从g中移除满足筛选条件f的所有卡。第三个参数开始是额外参数。
●Group Group.Merge(Group g1, Group g2)
把g2中的所有卡合并到g1。
注：g2本身不会发生变化。
●Group Group.Sub(Group g1, Group g2)
把g2中的所有卡合并到g1。
注：g2本身不会发生变化。
●bool Group.Equal(Group g1, Group g2)
判断g1和g2是否相同
●bool Group.IsContains(Group g, Card c)
检查g中是否存在卡片c
●Card Group.SearchCard(Group g, function f, ...)
过滤函数。返回g中满足筛选条件f的第一张卡。第三个参数为额外参数。