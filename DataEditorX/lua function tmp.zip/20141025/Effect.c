========== Effect ==========
●Effect Effect.CreateEffect(Card c)
新建一个空效果,并且效果的拥有者为c
●Effect Effect.GlobalEffect()
新建一个全局效果
●Effect Effect.Clone(Effect e)
新建一个效果e的副本
●void Effect.Reset(Effect e)
把效果e重置。重置之后不可以再使用此效果
●int Effect.GetFieldID(Effect e)
获取效果e的id
●void Effect.SetType(Effect e, int type)
为效果e设置Type属性
●void Effect.SetDescription(Effect e, int desc)
为效果e设置效果描述
●void Effect.SetCode(Effect e, int code)
为效果e设置Code属性
●void Effect.SetRange(Effect e, int range)
为效果e设置Range属性
●void Effect.SetTargetRange(Effect e, int s_range, int o_range)
为效果e设置Target Range属性
	s_range指影响的我方区域。
	o_range值影响的对方区域。
	如果property属性中指定了EFFECT_FLAG_ABSOLUTE_RANGE标志，
		那么s_range指玩家1收到影响的区域，o_range指玩家2受到影响的区域。
	如果这是一个特殊召唤手续(EFFECT_SPSUMMON_PROC)的效果，
		并且property指定了EFFECT_FLAG_SPSUM_PARAM标志，
		那么s_range表示特殊召唤到的哪个玩家的场地，
	o_range表示可选择的表示形式。
●void Effect.SetAbsoluteRange(Effect e, int playerid,int s_range, int o_range)
设置target range属性并设置EFFECT_FLAG_ABSOLUTE_RANGE标志
	playerid != 0 s_range和o_range反转
●void Effect.SetCountLimit(Effect e, int count [,int code = 0])
设置一回合可以发动的次数count（仅触发型效果有效）
	code 【未知】
●void Effect.SetReset(Effect e, int reset_flag, [int reset_count = 1])
设置reset参数
●void Effect.SetProperty(Effect e, int prop)
设置Property属性
●void Effect.SetLabel(Effect e, int label)
设置Label属性
●void Effect.SetLabelObject(Effect e, Card|Group|Effect label)
设置Label属性
●void Effect.SetCategory(Effect e, int cate)
设置Category属性
●void Effect.SetHintTiming(Effect e, int s_time, [int o_time=s_time])
设置提示时间
●void Effect.SetCondition(Effect e, function con_func)
设置Condition属性
●void Effect.SetTarget(Effect e, function targ_func)
设置Target属性
●void Effect.SetCost(Effect e, function cost_func)
设置Cost属性
●void Effect.SetValue(Effect e, int|function val)
设置Value属性
●void Effect.SetOperation(Effect e, function op_func)
设置Operation属性
●void Effect.SetOwnerPlayer(Effect e, int player)
设置Owner player属性
●int Effect.GetDescription(Effect e)
返回效果描述
●int Effect.GetCode(Effect e)
返回code属性
●int Effect.GetType(Effect e)
返回Type属性
●int Effect.GetProperty(Effect e)
返回Property属性
●int Effect.GetLabel(Effect e)
返回Label属性
●Card|Group|Effect Effect.GetLabelObject(Effect e)
返回Label属性
●int Effect.GetCategory(Effect e)
返回Category属性
●Card Effect.GetOwner(Effect e)
返回效果拥有者
●Card Effect.GetHandler(Effect e)
返回效果在哪一张卡上生效(通常是注册该效果的卡)
●function Effect.GetCondition(Effect e)
返回condition属性
●function Effect.GetCost(Effect e)
返回cost属性
●function Effect.GetTarget(Effect e)
返回target属性
●function Effect.GetOperation(Effect e)
返回operation属性
●function|int Effect.GetValue(Effect e)
返回value属性
●int Effect.GetOwnerPlayer(Effect e)
返回所有者
●int Effect.GetHandlerPlayer(Effect e)
返回当前者
●int Effect.GetActivateLocation(Effect e)
返回活动区域
●int Effect.GetActiveType(Effect e)
返回当前的效果类型
●bool Effect.IsActivatable(Effect e,int playerid)
检查当前的效果活动区域
●int Effect.IsActiveType(Effect e, int type)
检查当前的效果类是否等于type
●bool Effect.IsHasProperty(Effect e, int prop)
检查效果是否含有标志prop
●bool Effect.IsHasCategory(Effect e, int cate)
检查效果是否含有效果分类cate
●bool Effect.IsHasType(Effect e, int type)
检查效果是否属于类型type