
========== Duel ==========
●integer Duel.AdjustInstantly(Card c)
●integer Duel.AnnounceAttribute(integer player, integer count, integer available)
让玩家player从可选的属性中宣言count个属性。available是所有可选属性的组合值。
●integer Duel.AnnounceCard(integer player)
让玩家player宣言一个卡片代号。
●integer Duel.AnnounceCoin(integer player)
让玩家player宣言硬币的正反面。
●integer Duel.AnnounceLevel(int playerid)
●integer Duel.AnnounceNumber(integer player, ...)
让玩家player宣言一个数字。从第二个参数开始，每一个参数代表一个可宣言的数字。
返回选择的选项的序号。
●integer Duel.AnnounceRace(integer player, integer count, integer available)
让玩家player从可选的种族中宣言count个种族。available是所有可选种族的组合值。
●integer Duel.AnnounceType(integer player)
让玩家player宣言一个卡片类型。
●void Duel.BreakEffect()
中断当前效果，使之后的效果处理视为不同时处理。此函数会造成错时点。
●void Duel.CalculateDamage(Card attacker,Card attack_target,bool skip_timing)
●void Duel.ChainAttack()
使攻击卡再进行一次连续攻击（开辟，破灭的女王）
●void Duel.ChaingeAttacker(Card c)
把当前的攻击卡替换成c进行攻击
●void Duel.ChaingeAttackTarget(Card c)
把当前的攻击目标替换成c。如果c=nil则变成直接攻击。
●void Duel.ChangeBattleDamage(integer player, integer value)
把玩家player在本次战斗中收到的伤害变成value
●void Duel.ChangeChainOperation(integer chainc, function f)
把连锁chainc的效果的处理函数换成f。用于实现“把效果变成”等的效果
●integer Duel.ChangePosition(Card|Group targets,integer au,[integer ad=au, integer du=au, integer dd=au, boolean noflip=false])
改变targets的表示形式。表侧攻击表示的变成au，里侧攻击表示的变成ad, 
表侧守备表示变成du,里侧守备表示变成dd
如果noflip=true则不触发翻转效果（但会触发翻转时的诱发效果）
●void Duel.ChangeTargetCard(integer chainc, Group g)
Duel.ChangeTarget
把连锁chainc的对象换成g
●void Duel.ChangeTargetParam(integer chainc, integer param)
把连锁chainc的对象参数换成param
●void Duel.ChangeTargetPlayer(integer chainc, integer player)
把连锁chainc的对象玩家换成player
●boolean Duel.CheckAttackActivity(integer player)
检查玩家player本回合有没有进行过攻击。
●boolean Duel.CheckChainTarget(integer chainc, Card c)
检查c是否是连锁chainc的正确的对象
●boolean Duel.CheckChainUniqueness()
检查当前连锁中是否存在同名卡的发动。true表示无同名卡。
●boolean|Group,integer,integer,Effect,integer,integer Duel.CheckEvent(integer event)
检查当前是否是event时点
●boolean Duel.CheckFlipSummonActivity(integer player)
检查玩家player本回合有没有进行过特殊召唤的行为。
特殊召唤的行为包括：
进行了入连锁和不入连锁的特殊召唤；
发动了确定要特殊召唤的效果但是效果被无效
不包括：发动了确定要特殊召唤的效果但是发动被无效
●boolean Duel.CheckLocation(integer playerid,integer location,integer sequence)
●boolean Duel.CheckLPCost(integer player, integer cost)
检查玩家player是否能支付cost点lp
●boolean Duel.CheckNormalSummonActivity(integer player)
检查玩家player本回合有没有进行过通常召唤的行为。包括召唤和set
●boolean Duel.CheckPhaseActivity()
●boolean Duel.CheckReleaseGroup(integer playerid[,integer use_con,integer fcount,integer  pexception)
●boolean Duel.CheckReleaseGroupEx(int playerid,int use_con,int fcount, int pexception)
●boolean Duel.CheckRemoveOverlayCard(int playerid, int s,int o,int count,int reason)
●boolean Duel.CheckSpecialSummonActivity(integer player)
-Duel.CheckSummonActivity
检查玩家player本回合有没有进行过召唤的行为。
召唤被无效视作进行过召唤行为。
●boolean Duel.CheckSummonActivity(integer player)
-Duel.CheckSpecialSummonActivity
检查玩家player本回合有没有进行过召唤的行为。
召唤被无效视作进行过召唤行为。
●boolean Duel.CheckSummonedCount()
Duel.CheckSummonCount
检查回合玩家本回合的通常召唤限制计数。
●boolean Duel.CheckSynchroMaterial(Card c, function f1, function f2, integer min,integer max,Card smat,Group mg)
检查是否存在一组满足条件的卡作为同调召唤c的素材。f1,f2,min同上。
●boolean Duel.CheckTiming(integer time)
●boolean Duel.ChecktReleaseGroup(integer player, function f, integer count, Card ex, ...)
可能过时。
过滤函数，检查玩家player是否存在至少count张不等于ex的满足条件f的可解放的卡
●boolean Duel.CheckTunerMaterial(Card c, Card tuner, function f1, function f2, integer min,integer max,Card smat,Group mg)
检查以tuner作为调整是否存在一组满足条件的卡作为同调召唤c的素材。f1,f2,min同上。
●boolean Duel.CheckXyzMaterial(Card c,function f,int minc,int maxc,Group mg)
●void Duel.ClearTargetCard(int playerid,Card c|Group g)
●void Duel.ConfirmCards(integer player, Card|Group targets)
给玩家player确认targets
●void Duel.ConfirmDeckTop(integer player, integer count)
确认玩家player卡组最上方的count张卡。双方均可确认。
●Card|false Duel.CreateToken(integer player, integer code[, integer setcode,integer attack, integer defence, integer level, integer race, integer attribute])
以传入的参数数值新建一个Token
●integer Duel.Damage(integer player, integer value, integer reason)
以reason原因给与玩家player造成value的伤害。返回实际收到的伤害值。
如果受到伤害变成回复等效果的影响时，返回值为0.
●void Duel.DebugMessage(any msg)
Debug用函数，用于显示信息
●integer Duel.Destroy(Card|Group targets, integer reason,integer dest)
以reason原因破坏targets。返回值是实际被破坏的数量。
如果reason包含REASON_RULE，则破坏事件将不会检查卡片是否免疫效果，
不会触发代破效果并且无视“不能破坏”。
●void Duel.DisableAttack()
使本次攻击无效
●void Duel.DisableShuffleCheck()
使下一个操作不检查是否需要洗卡组或者洗手卡。
注：如果不调用此函数，
除了调用Duel.DiscardDeck和Duel.Draw之外从卡组中取出卡或者把卡加入手卡
或者把卡加入卡组（非最上端或最底端）时，系统会自动在效果处理结束时洗卡组或手卡。
如果不希望如此，比如从卡组顶端除外一张卡等操作，那么需要调用此函数。
此函数仅保证紧接着的一次操作不会进行洗卡检测。
●integer Duel.DiscardDeck(integer player, integer count, integer reason)
以原因reason把玩家player的卡组最上端count张卡送去墓地.返回实际转移的数量。
●integer Duel.DiscardHand(integer player, function f,integer min, integer max, integer reason, Card ex, ...)
过滤函数。让玩家player选择并丢弃满足筛选条件f兵不等于ex的min-max张手卡。
第7个参数开始为额外参数。
●integer Duel.Draw(integer player, integer count, integer reason)
让玩家player以原因reason抽count张卡。返回实际抽的卡的数量。
如果reason含有REASON_RULE则此次抽卡不受“不能抽卡”的效果的影响。
●void Duel.EnableGlobalFlag(int flag)
●boolean Duel.Equip(integer player, Card c1, Card c2)
把c1作为玩家player的装备卡装备给c2。返回值表示是否成功。
●void Duel.EquipComplete()
●Group Duel.FlipSummonedCardsThisTurn(int playerid)
●Card Duel.GetAttacker()
返回此次战斗攻击的卡
●Card Duel.GetAttackTarget()
返回此次战斗被攻击的卡。如果返回nil表示是直接攻击。
●integer Duel.GetBattleDamage(integer player)
返回玩家player在本次战斗中收到的伤害
●... Duel.GetChainInfo(integer chainc, ...)
返回连锁chainc的信息。如果chainc=0，则返回当前正在处理的连锁的信息。
此函数根据传入的参数个数按顺序返回相应数量的返回值。参数可以是:
CHAININFO_CHAIN_COUNT           连锁序号
CHAININFO_TRIGGERING_EFFECT     连锁的效果
CHAININFO_TRIGGERING_PLAYER     连锁的玩家
CHAININFO_TRIGGERING_CONTROLER      连锁发生位置所属玩家
CHAININFO_TRIGGERING_LOCATION       连锁发生位置
CHAININFO_TRIGGERING_SEQUENCE       连锁发生的位置的序号
CHAININFO_TARGET_CARDS          连锁的对象卡片组
CHAININFO_TARGET_PLAYER         连锁的对象玩家
CHAININFO_TARGET_PARAM          连锁的对象参数
CHAININFO_DISABLE_REASON        连锁被无效的原因效果
CHAININFO_DISABLE_PLAYER        连锁被无效的原因玩家
CHAININFO_CHAIN_ID          连锁的唯一标识
举例：
Duel.GetChainInfo(0,CHAININFO_TRIGGERING_LOCATION,CHAININFO_TARGET_CARDS)
将会返回当前连锁发生的位置和对象卡。
●Effect Duel.GetChainMaterial(integer player)
返回玩家player受到的连锁素材的效果。此函数仅用于融合类卡的效果。

●integer Duel.GetCoinResult()
●boolean Duel.GetControl(Card c,integer player,int reset_phase,int reset_count)
让玩家player得到c的控制权。返回值表示是否成功。
●integer Duel.GetCounter(integer player, integer s, integer o,integer countertype)
返回场上存在的countertype类型的指示物的数量。s和o参数作用同上。
●integer Duel.GetCurrentChain()
返回当前正在处理的连锁序号
●integer Duel.GetCurrentPhase()
返回当前的阶段
●Group Duel.GetDecktopGroup(integer player, integer count)
返回玩家player的卡组最上方的count张卡
●Ginteger Duel.GetDiceResult()
●integer Duel.GetDrawCount(integer player)
返回玩家player每回合的规则抽卡数量
●integer,integer Duel.GetEnvironment()
返回code,player
●Group Duel.GetExceedMaterial(Card c)
返回c的超量素材
●Card Duel.GetFieldCard(integer controler, integer location, integer sequence)
返回指定玩家指定地点指定序号的卡
●Group Duel.GetFieldGroup(integer player, integer s, integer o)
返回指定位置的卡。s指对玩家player来说的己方的位置，
o指对玩家player来说的对方的位置。下面提到的指定位置均为此意。
比如Duel.GetFieldGroup(0,LOCATION_GRAVE,LOCATION_MZONE)
返回玩家1墓地和玩家2的怪兽区的所有卡
●integer Duel.GetFieldGroupCount(integer player, integer s, integer o)
同上，返回值变成卡的数量
●Card Duel.GetFirstMatchingCard(function f, integer player, integer s, integer o, Card ex, ...)
过滤函数，返回指定位置满足过滤条件f并且不等于ex的第一张卡。
第6个参数开始为额外参数。
●Card Duel.GetFirstTarget()
●integer Duel.GetFlagEffect(integer player, integer code)
返回玩家player的特定的标识效果的数量
●integer Duel.GetLocationCount(integer player, integer location[,int uplayer,int reason)
返回玩家player的指定场地location剩余的空格数。
location只能是LOCATION_MZONE或者LOCATION_SZONE。
●integer Duel.GetLP(integer player)
返回玩家player的当前LP
●Group Duel.GetMatchingGroup(function f, integer player, integer s, integer o, Card ex, ...)
过滤函数，返回指定位置满足过滤条件f并且不等于ex的卡。
第6个参数开始为额外参数。
●integer Duel.GetMatchingGroupCount(function f, integer player, integer s, integer o, Card ex, ...)
同上，返回值变成符合的卡的数量。
●Group Duel.GetOperatedGroup()
此函数返回之前一次卡片操作实际操作的卡片组。包括
Duel.Destroy, Duel.Remove, Duel.SendtoGrave, 
Duel.SendtoHand, Duel.SendtoDeck, Duel.Release, 
Duel.ChangePosition, Duel.SpecialSummon
●integer Duel.GetOperationCount(integer chainc)
返回连锁chainc包含的操作分类的数量
●... Duel.GetOperationInfo(integer chainc, integer category)
返回连锁chainc的category分类的操作信息。返回值为5个，
第一个返回值是false的话表示不存在该分类。后4个返回值对应上一个函数的后4个参数。
●Integer Duel.GetOverlayCount(integer player, integer s, integer o)
返回指定位置的所有叠放的卡的数量
●Group Duel.GetOverlayGroup(integer player, integer s, integer o)
返回指定位置的所有叠放的卡
●Group Duel.GetReleaseGroup(integer player)
返回玩家player可解放（非上级召唤用)的卡片组
●integer Duel.GetReleaseGroupCount(integer player [,bool hand])
返回玩家player可解放（非上级召唤用)的卡片数量
●Group Duel.GetRitualMaterial(integer player)
返回玩家player可用的用于仪式召唤素材的卡片组。
包含手上，场上可解放的以及墓地的仪式魔人等卡。
●integer Duel.GetTargetCount(function f, integer player, integer s, integer o, Card ex, ...)
基本同Duel.GetMatchingGroupCount，
不同之处在于需要追加判定卡片是否能成为当前正在处理的效果的对象。
●integer Duel.GetTributeCount(Card c)
返回用于通常召唤c的祭品数量。
此数量不一定等于上一个函数的返回值中的卡片数量。
因为某些卡可以作为两个祭品来使用。
●Group Duel.GetTributeGroup(Card c)
返回用于通常召唤c可解放（上级召唤用)的卡片组
●integer Duel.GetTurnCount()
返回当前的回合数
●integer Duel.GetTurnPlayer()
返回当前的回合玩家
●void Duel.Hint(integer player, integer desc)
给玩家发送内置消息提示
●void Duel.HintSelection(Group g)
●void Duel.IncreaseSummonedCount(Card c)
●void Duel.IncreaseSummonCount()
本回合的通常召唤限制计数+1
●boolean Duel.IsCanRemoveCounter(integer player, integer s,integer o, integer countertype, integer count, integer reason)
检查玩家player是否能移除场上的countertype类型的count个指示物。
s和o参数作用同上。
●boolean Duel.IsChainDisablable(integer chainc)
检查连锁chainc的效果是否可以被无效化
●boolean Duel.IsChainNegatable(int32 chaincount)
●boolean Duel.IsChainInactivatable(integer chainc)
检查连锁chainc的发动是否可以被无效化
●boolean Duel.IsDamageCalculated()
用于在伤害阶段检查是否已经计算了战斗伤害。
●boolean Duel.IsEnvironment(int code,int playerid)
●boolean Duel.IsExistingMatchingCard(function f, integer player, integer s, integer o, integer count, Card ex, ...)
过滤函数，检查指定位置是否存在至少count张满足过滤条件f并且不等于ex的卡。
第7个参数开始为额外参数。
●boolean Duel.IsExistingTarget(function f, integer player, integer s, integer o, integer count, Card ex, ...)
过滤函数，检查指定
位置是否存在至少count张满足过滤条件f并且不等于ex
并且可以成为当前正在处理的效果的对象的卡。
第7个参数开始为额外参数。
●boolean Duel.IsPlayerAffectedByEffect(int playerid,int code)
●boolean Duel.IsPlayerAffectByEffect(integer player, integer code)
检查玩家player是否受特性效果的影响
●boolean Duel.IsPlayerCanDiscardDeck(integer player,int count)
检查玩家player是否可以把卡组顶端的卡送去墓地
●boolean Duel.IsPlayerCanDiscardDeckAdCost(integer player, int count)
检查玩家player是否可以把卡组顶端的卡送去墓地作为cost。
当卡组没有足够数量的卡，
或者当卡组中的卡受到送墓转移效果的影响时（如大宇宙，次元裂缝，即使不是全部）
此函数会返回false
●boolean Duel.IsPlayerCanDraw(integer player)
检查玩家player是否可以效果抽卡
●boolean Duel.IsPlayerCanFlipSummon(integer player, Card c)
检查玩家player是否可以反转召唤c。
●boolean Duel.IsPlayerCanFlipSummonCount(int playerid,int count)
●boolean Duel.IsPlayerCanRelease(integer player, Card c)
检查玩家是否能解放c
●boolean Duel.IsPlayerCanRemove(integer player, Card c)
检查玩家是否能除外c
●boolean Duel.IsPlayerCanSendtoDeck(integer player, Card c)
检查玩家是否能把c送去卡组
●boolean Duel.IsPlayerCanSendtoGrave(integer player, Card c)
检查玩家是否能把c送去墓地
●boolean Duel.IsPlayerCanSendtoHand(integer player, Card c)
检查玩家是否能把c送去手牌
●boolean Duel.IsPlayerCanSpecialSummon(int playerid,int sumtype.int sumpos,int toplayer,card c)
●boolean Duel.IsPlayerCanSpecialSummonCount(int playerid,int count)
●boolean Duel.IsPlayerCanSpecialSummonMonster(integer player, integet code, integer setcode, integer attack, integer defence integer level, integer race, integer attribute, [integer pos=POS_FACEUP, integer target_player=player])
检查玩家player是否可以以pos的表示形式特殊召唤特定属性值的怪物到target_player场上。
此函数通常用于判定是否可以特招token和陷阱怪物。
●boolean Duel.IsPlayerCanSummon(integer player, integer sumtype, Card c)
检查玩家player是否可以以sumtype方式通常召唤c。
仅当玩家收到“不能上级召唤”等效果的影响时返回false。
●boolean Duel.IsPlayerCanSummonCount(int playerid,int count)
●void Duel.MajesticCopy(Card c1,Card c2)
●void Duel.MoveSequence(Card c, integer seq)
移动c的序号。通常用于在场上换格子或者在卡组中移动到最上方或者最下方。
●void Duel.MoveToField(Card c, integer move_player, integer target_player,integer dest, integer pos, boolean enabled)
让玩家move_player把c移动的target_player的场上。
dest只能是LOCATION_MZONE或者LOCATION_SZONE。pos表示可选表示形式。
enable表示是否立刻适用c的效果。
●void Duel.MSet(integer player, Card c, boolean ignore_count, Effect e)
让玩家以效果e对c进行通常召唤的Set。
如果e=nil,那么就按照一般的通常召唤规则进行通常召唤。
如果ignore_count=true，则忽略每回合的通常召唤次数限制。
●void Duel.NegateActivation(integer chainc)
使连锁chainc的发动无效
●void Duel.NegateAttack()
●void Duel.NegateEffect(integer chainc)
使连锁chainc的效果无效
●void Duel.NegateRelatedChain(Card c,int reset)
●void Duel.NegateSummon(Card c)
使正在召唤，反转召唤，特殊召唤的c的召唤无效
●Group Duel.NormalSummonedCardsThisTurn(int playerid)
●void Duel.Overlay(Card c, Card|Group ocard)
把ocard作为c的叠放卡叠放
●void Duel.PayLPCost(integer player, integer cost)
让玩家player支付cost点lp
●void Duel.RaiseEvent(Group eg,integer code, Effect reason_effect,integer reason,integer reason_player,integer event_player,integer event param)
触发一个事件。
●void Duel.RaiseSingleEvent(Card ec,integer code, Effect reason_effect,integer reason,integer reason_player,integer event_player, integer event param)
触发一个单体事件。
●void Duel.Readjust()
刷新场上的卡的信息。非特定情况或者不清楚原理请勿使用此函数以免形成死循环。
●integer Duel.Recover(integer player, integer value, integer reason)
以reason原因使玩家player回复value的LP。返回实际的回复值。
如果受到回复变成伤害等效果的影响时，返回值为0.
●void Duel.RegisterEffect(Effect e, integer player)
把效果作为玩家player的效果注册给全局环境。
●Effect Duel.RegisterFlagEffect(integer player, integer code, integer reset_flag, integer property, integer reset_count)
此函数为玩家player注册全局环境下的标识效果。
此效果总是影响玩家的(EFFECT_FLAG_PLAYER_TARGET)并且不会被无效化。
其余部分与Card.RegisterFlagEffect相同
●integer Duel.Release(Card|Group targets, integer reason)
以reason原因解放targets。返回值是实际解放的数量。
如果reason含有REASON_COST，则不会检查卡片是否不受效果影响
●void Duel.ReleaseRitualMaterial(Group g)
解放仪式用的素材g。如果是墓地的仪式魔人等卡则除外。
●integer Duel.Remove(Card|Group targets, integer pos, integer reason)
以reason原因，pos表示形式除外targets。
返回值是实际被操作的数量。
如果reason包含REASON_TEMPORARY，
那么视为是暂时除外，可以通过Duel.ReturnToField返回到场上
●void Duel.RemoveCounter(integer player, integer s, integer o,integer countertype, integer count, integer reason)
让玩家player移除场上存在的countertype类型的count个指示物。
s表示对player来说的己方的可移除指示物的位置，
o表示对player来说的对方的可移除指示物的位置
●void Duel.RemoveOverlayCard(integer player, integer s, integer o, integer min, integer max, integer reason)
以reason原因移除指定位置的min-max张叠放卡
●void Duel.ReplaceAttacker(Card c)
用c代替当前攻击的卡进行伤害阶段
●void Duel.ReplaceAttackTarget(Card c)
(预留）
●void Duel.ResetFlagEffect(integer player, integer code)
手动reset玩家player的特定的标识效果
●void Duel.ReturnToField(Card c)
把c返回到场上。c必须是以REASON_TEMPORARY原因离场，并且离场后没有离开过那个位置。
●integer Duel.SelectDisableField(integer player, integer count, integer s, integer o, integer filter)
让玩家player选择指定位置的count个位置不能使用。
●boolean Duel.SelectEffectYesNo(integer player, integer code)
让玩家选择是否发动卡的效果
●Group Duel.SelectFusionMaterial(integer player, Card c, Group g)
让玩家player从g中选择一组满足c的融合素材的卡
●Group Duel.SelectMatchingCard(integer sel_player, function f, integer player,integer s, integer o, integer min, integer max, Card ex, ...)
过滤函数，让玩家sel_player选择指定位置满足过滤条件f并且不等于ex的min-max张卡。
第9个参数开始为额外参数。
●integer Duel.SelectOption(integer player, ...)
让玩家选择选项。从第二个参数开始，每一个参数代表一条选项。
返回选择的选项的序号。
●void Duel.SelectPosition(int playerid,Card c,int pos)
●Group Duel.SelectReleaseGroup(integer player, function f, integer min, integer max, Card ex, ...)
过滤函数，让玩家player选择min-max张不等于ex的满足条件f的可解放的卡并返回
●Group Duel.SelectReleaseGroupEx(integer player, function f, integer min, integer max, Card ex, ...)
过滤函数，让玩家player选择min-max张不等于ex的满足条件f的可解放的卡并返回
●void Duel.SelectSequence()
(预留）
●Group Duel.SelectSynchroMaterial(integer player, Card c, function f1, function f2, integer min)
让玩家选择用于同调c需要的满足条件的数量至少是min的一组素材。
f1是调整需要满足的过滤条件。f2是调整以外的部分需要满足的过滤条件。
●Group Duel.SelectTarget(integer sel_player, function f, integer player, integer s, integer o, integer min, integer max,Card ex, ...)
过滤函数，让玩家sel_player选择指定
位置满足过滤条件f并且不等于ex
并且可以成为当前正在处理的效果的对象的min-max张卡。
第9个参数开始为额外参数。
此函数会同时酱当前正在处理的连锁的对象设置成选择的卡
●Group Duel.SelectTribute(integer player, Card c, integer min, integer max)
让玩家player选择用于通常召唤c的min-max个祭品。
●Group Duel.SelectTunerMaterial(integer player, Card c, Card tuner, function f1, function f2, integer min)
让玩家选择用于同调c需要的满足条件的以tuner作为调整的数量至少是min的一组素材。
f1是调整需要满足的过滤条件。f2是调整以外的部分需要满足的过滤条件。
●void Duel.SelectXyzMaterial(int playerid,Card c,int min,int max)
●boolean Duel.SelectYesNo(integer player, integer desc)
让玩家选择是或否
●integer Duel.SendtoDeck(Card|Group targets, integer player | nil, integer seq, integer reason)
以reason原因把targets送去玩家player的卡组。
返回值是实际被操作的数量。
如果player是nil则返回卡的持有者的卡组。
如果seq=0，则是返回卡组最顶端；seq=1则是返回卡组最低端；
其余情况则是返回最顶端并且标记需要洗卡组。
●integer Duel.SendtoGrave(Card|Group targets, integer reason)
以reason原因把targets送去墓地。返回值是实际被操作的数量。
●integer Duel.SendtoHand(Card|Group targets,integer player | nil, integer reason)
以reason原因把targets送去玩家player的手牌。
返回值是实际被操作的数量。
如果player是nil则返回卡的持有者的手牌。
●void Duel.SetChainLimit(function f)
设定连锁条件。f是接受一个Effect类型作为参数并且返回boolean值的函数。
在cost或者target处理中调用此函数可以限制可以连锁的效果的种类（如超融合）
。如果f返回false表示不能连锁。一旦设置连锁条件后发生了新的连锁那么连锁条件将会解除。
●void Duel.SetChainLimitTillChainEnd(function f)
功能同上，但是此函数设定的连锁条件直到连锁结束才会解除。
●void Duel.SetCoinResult( ... )
强行修改投硬币的结果。此函数用于永续的EVENT_TOSS_COIN事件中
●void Duel.SetDiceResult( ... )
强行修改投骰子的结果。此函数用于永续的EVENT_TOSS_DICE事件中
●void Duel.SetFusionMaterial(Group g)
设置g为需要使用的融合素材
●void Duel.SetLP(integer player, integer lp)
设置玩家player的当前LP为lp
●void Duel.SetOperationInfo(integer chainc, integer category, Card|Group targets, integer count, integer target_player, integer target_param)
设置当前处理的连锁的操作信息。此操作信息包含了效果处理中确定要处理的效果分类。
比如潜行狙击手需要设置CATEGORY_DICE，但是不能设置CATEGORY_DESTROY，因为不确定。
对于破坏效果，targets需要设置成发动时可能成为连锁的影响对象的卡，
并设置count为发动时确定的要处理的卡的数量。
比如黑洞发动时，targets需要设定为场上的所有怪物，count设置成场上的怪的数量。
对于CATEGORY_SPECIAL_SUMMON,CATEGORY_TOHAND,CATEGORY_TODECK等分类，
如果取对象则设置targets为对象，count为对象的数量；
如果不取对象则设置targets为nil,count为预计要处理的卡的数量，
并设置target_param为预计要处理的卡的位置。
例如增援：SetOperationInfo(0,CATEGORY_TOHAND,nil,1,0,LOCATION_DECK)。
操作信息用于很多效果的发动的检测，例如星尘龙，王家沉眠之谷等。
●void Duel.SetSynchroMaterial(Group g)
设置g为需要使用的同调素材
●void Duel.SetTargetCard(Group g)
把当前正在处理的连锁的对象设置成g。
注，这里的对象指的的广义的对象，包括不取对象的效果可能要处理的对象。
●void Duel.SetTargetParam(integer param)
把当前正在处理的连锁的对象参数设置成param。
●void Duel.SetTargetPlayer(integer player)
把当前正在处理的连锁的对象玩家设置成player。
●void Duel.ShuffleDeck(integer player)
手动洗玩家player的卡组
●void Duel.ShuffleHand(integer player)
手动洗玩家player的手卡
注：以上两个操作会重置洗卡检测的状态。
●void Duel.ShuffleSetCard(Group g)
●void Duel.SkipPhase(integer player, integer phase, integer reset_flag, integer reset_count)
跳过玩家player的phase阶段，并在特定的阶段后reset。reset参数和效果相同。
●void Duel.SortDecktop(integer sort_player, integer target_player, integer count)
让玩家sort_player对玩家target_player的卡组最上方count张卡进行排序
●integer Duel.SpecialSummon(Card|Group targets, integer sumtype, integer sumplayer, integer target_player, boolean nocheck, boolean nolimit,integer pos)
让玩家player以sumtype方式，pos表示形式把targets特殊召唤到target_player场上。
如果nocheck为true则无视卡的召唤条件。如果nolimit为true则无视卡的苏生限制。
返回值是特殊召唤成功的卡的数量。
●integer Duel.SpecialSummonComplete()
此函数在确定复数个上一个函数调用完毕之后调用。用于触发事件。
●integer Duel.SpecialSummonedCardsThisTurn()
●void Duel.SpecialSummonRule(integer player, Card c)
让玩家player对c进行特殊召唤手续。
●boolean Duel.SpecialSummonStep(Card c, integer sumtype, integer sumplayer,integer target_player, boolean nocheck, boolean nolimit, integer pos)
此函数是上一个函数的分解过程，只特殊召唤一张卡c。
此函数用于一个效果需要双方同时特殊召唤时。此函数必须和下面的函数一起使用。
返回值表示是否特殊召唤成功。
●void Duel.SSet(integer player, Card c)
让玩家player把c放置到魔法陷阱区
●void Duel.Summon(integer player, Card c, boolean ignore_count, Effect e)
让玩家以效果e对c进行通常召唤（非set)。
如果e=nil,那么就按照一般的通常召唤规则进行通常召唤。
如果ignore_count=true，则忽略每回合的通常召唤次数限制。
●void Duel.SummonedCardsThisTurn(int playerid)
●boolean Duel.SwapControler(Card c1, Card c2)
交换c1和c2的控制权。返回值表示是否成功。
●boolean Duel.SwapDeckAndGrave(integer player)
现世与冥界的逆转专用。把玩家player的卡组和墓地交换
●void Duel.SynchroSummon(integer player, Card c, Card tuner)
让玩家player以tuner作为调整对c进行特殊召唤手续。
●... Duel.TossCoin(integer player, integer count)
让玩家player投count次硬币。返回值为count个结果。结果是0或者1.
●... Duel.TossDice(integer player, integer count)
让玩家player投count次骰子。返回值为count个结果。结果是1-6.
●boolean Duel.VenomSwampCheck(int playerid,Card c)
●void Duel.Win(function f, Effect e, integer player)
在当前效果处理完之后调用f进行胜负检测。e和player作为f的两个参数传递给f。
f返回值的低16位表示胜负判定玩家，
0表示玩家1胜利，1表示玩家2胜利，2表示平局，
此外是无胜负兵继续进行。高16位表示胜负的原因。
●void Duel.XyzSummon(int playerid, Card c, Group g)