﻿
★File association
.lua notepad++/sublime text/DataEditorX
.cdb DataEditorX

★Feedback
Email:247321453@qq.com or keyoyu@foxmail.com

Title：(DataEditorX+Version)
Content：Error Message
★Language setting
DataEditorX.exe.config
<add key="language" value="english" />

★DataEditor：
1.tips text：Click line and Edit，"Enter" save Edit.
2.Atk/Eef=？ , input ? or -2 or ？
Foldet:
pics,script and cdb's folder is a same

Cards Copy：
Replace：Yes:If exists then replace old /NO:If exists then ignore

Search Cards:
1.Search By setcode: only one
2.Search By Desc，Rule，attribute，level，race，card type，category
3.search By ATK/DEF：
	atk/def = 0   input: -1
	atk/def = ?   input: -2 or ?
4.Search By Name :
	A.O.J%%		
	流%%天		
	%%战士		
5.Searcg By Code：
--code  = 10000000          card code： 10000000 card alias: 0
--alias = 10000000          card code： 10000000 card alias:10000000 
--10000000<=code<=20000000  card code： 10000000 card alias:20000000


★Magic Set Editor 2
Download/Update："Magic Set Editor 2/download.bat"

★MSE-set setting
mse-head 		MSE set info setting
mse-monster		other monster setting
mse-pendulum	pendulum monster setting
mse-spelltrap	spell/trap setting
mse-config		spell/trap text,pendulum rule,maxcount,imagepath

1.Pendulum for english
Pendulum Scale = 10
Pendulum Text :
xxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxx

Monster Text :
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxx

2.english/mse-config.txt

pendulum-text = Pendulum Text :\n([\S\s]*?)\n\n
monster-text = Monster Text :\n([\S\s]*)

★CodeEditor
input keyword in bottom textbox , "Enter"
Ctrl+Mouse.Left 	Goto Function define
Ctrl+Mouse.capture 	Setting Scale
