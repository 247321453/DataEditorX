﻿1.pendulum 请统一卡片的描述，目前cdb里面的太乱了。

Pendulum Scale = 10
Pendulum Text :
xxxxxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxxxx

Monster Text :
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxx



2.english/mse-config.txt

pendulum-text = Pendulum Text :\n([\S\s]*?)\n\n
monster-text = Monster Text :\n([\S\s]*)